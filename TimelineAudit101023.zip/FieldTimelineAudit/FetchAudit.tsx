import * as React from "react";

export interface IAuditDetail {
  dateaudited: string;
  user: string;
  oldValue: string;
  newValue: string;
}

export interface IAuditCollection {
  auditRecords: IAuditDetail[];
}

export interface IAttributeFormattedValue {
  oldValue: any;
  newValue: any;
}

export default function FetchAudit(props: any) {
  const [auditColl, setAuditColl] = React.useState<IAuditDetail[]>([]);
  const [loadMessage, setMessage] = React.useState("");
  const [formattedValueColl, setFormattedValueColl] = React.useState<
    IAttributeFormattedValue[]
  >([]);

  React.useEffect(() => {
    setMessage("loading");
    var isFormattedFieldType = props.fieldType == "1" || props.fieldType == "2";
    if (isFormattedFieldType) {
      fetchChangeHistory(props);
    } else {
      fetchAuditDetail(props, isFormattedFieldType, []);
    }
  }, []);

  function fetchAuditDetail(
    props: any,
    isFormattedFieldType: boolean,
    fcoll: IAttributeFormattedValue[]
  ) {
    fetch(props.fetchUrl, {
      method: "GET",
      headers: {
        "OData-MaxVersion": "4.0",
        "OData-Version": "4.0",
        "Content-Type": "application/json; charset=utf-8",
        Accept: "application/json",
        Prefer: "odata.include-annotations=*",
      },
    })
      .then((res) => res.json())
      .then(
        (result) => {
          console.log(result);
          if (result.value.length > 0) {
            const auditcollection: IAuditCollection = { auditRecords: [] };

            for (var i = 0; i < result.value.length; i++) {
              if (result.value[i].changedata.indexOf(props.attrName) > 0) {
                var dateField = new Date(result.value[i].createdon);
                var dateStr =
                  dateField.toLocaleDateString() +
                  " " +
                  dateField.toLocaleTimeString();
                var changeHistory = JSON.parse(result.value[i].changedata);
                for (
                  var j = 0;
                  j < changeHistory.changedAttributes.length;
                  j++
                ) {
                  if (
                    changeHistory.changedAttributes[j].logicalName ==
                    props.attrName
                  ) {
                    let oldVal = changeHistory.changedAttributes[j].oldValue;
                    let newVal = changeHistory.changedAttributes[j].newValue;
                    let attrName = props.attrName;

                    if (props.fieldType == "1") {
                      //lookup
                      let oldLookupArray = oldVal.split(",");
                      let newLookupArray = newVal.split(",");
                      oldVal = oldLookupArray[1];
                      newVal = newLookupArray[1];
                      attrName = "_" + props.attrName + "_value";
                    }

                    let auditRec: IAuditDetail = {
                      dateaudited: dateStr,
                      user: result.value[i][
                        "_userid_value@OData.Community.Display.V1.FormattedValue"
                      ],
                      oldValue: isFormattedFieldType
                        ? findAuditObj(attrName, oldVal, true, fcoll)
                        : oldVal,
                      newValue: isFormattedFieldType
                        ? findAuditObj(attrName, newVal, false, fcoll)
                        : newVal,
                    };
                    auditcollection.auditRecords.push(auditRec);
                  }
                }
              }
            }

            setAuditColl(auditcollection.auditRecords);
            setMessage("Loaded");
          }
        },
        // Note: it's important to handle errors here
        // instead of a catch() block so that we don't swallow
        // exceptions from actual bugs in components.
        (error) => {
          console.log(error);
          setMessage("Error");
        }
      );
  }

  function fetchChangeHistory(props: any) {
    fetch(props.fetchHistoryUrl, {
      method: "GET",
      headers: {
        "OData-MaxVersion": "4.0",
        "OData-Version": "4.0",
        "Content-Type": "application/json; charset=utf-8",
        Accept: "application/json",
        Prefer: "odata.include-annotations=*",
      },
    })
      .then((res) => res.json())
      .then(
        (result) => {
          console.log(result);
          var auditDetails = result.AuditDetailCollection.AuditDetails;
          var formattedCollection: IAttributeFormattedValue[] =
            auditDetails.map((elem: any) => {
              return { oldValue: elem.OldValue, newValue: elem.NewValue };
            });
          setFormattedValueColl(formattedCollection);
          return fetchAuditDetail(props, true, formattedCollection);
        },

        // Note: it's important to handle errors here
        // instead of a catch() block so that we don't swallow
        // exceptions from actual bugs in components.
        (error) => {
          console.log(error);
        }
      );
  }

  function findAuditObj(
    fieldName: string,
    fieldValue: string,
    fetchOldValue: boolean,
    formattedColl: IAttributeFormattedValue[]
  ) {
    let fValue: any = {};
    let actualValue: any = {};
    if (fetchOldValue) {
      fValue = formattedColl.find(
        (elem) => elem.oldValue[fieldName] == fieldValue
      );
      actualValue = fValue.oldValue;
    } else {
      fValue = formattedColl.find(
        (elem) => elem.newValue[fieldName] == fieldValue
      );
      actualValue = fValue.newValue;
    }
    return actualValue != null &&
      actualValue[fieldName + "@OData.Community.Display.V1.FormattedValue"] !=
        undefined
      ? actualValue[fieldName + "@OData.Community.Display.V1.FormattedValue"]
      : actualValue != null
      ? actualValue[fieldName]
      : "";
  }

  return (
    <main className="relative flex flex-col justify-center overflow-hidden">
      {/* <h1>{loadMessage}</h1> */}
      <div className="w-full max-w-6xl mx-auto px-4 md:px-6">
        <div className="flex flex-col justify-center divide-y divide-slate-200 [&>*]:py-12">
          <div className="w-full max-w-3xl mx-auto">
            {/* Vertical Timeline #1 */}
            <div className="-my-6">
              {/* Item #1 */}
              <div className="text-xl font-bold text-slate-900">
                <p className="break-all">{props.ctrlLabel}</p>
              </div>
              {auditColl.map((ar) => (
                <div
                  key={ar.dateaudited}
                  className="relative pl-8 sm:pl-32 py-6 group"
                >
                  <div className="flex flex-col sm:flex-row items-start mb-1 group-last:before:hidden before:absolute before:left-2 sm:before:left-0 before:h-full before:px-px before:bg-slate-300 sm:before:ml-[6.5rem] before:self-start before:-translate-x-1/2 before:translate-y-3 after:absolute after:left-2 sm:after:left-0 after:w-2 after:h-2 after:bg-indigo-600 after:border-4 after:box-content after:border-slate-50 after:rounded-full sm:after:ml-[6.5rem] after:-translate-x-1/2 after:translate-y-1.5">
                    <time className="sm:absolute left-0 translate-y-0.5 inline-flex items-center justify-center text-xs font-semibold uppercase w-20 h-6 mb-3 sm:mb-0 text-emerald-600 bg-emerald-100 rounded-full">
                      {ar.dateaudited}
                    </time>
                    <div className="text-xl font-bold text-slate-900">
                      <p className="break-all"> {ar.user}</p>
                    </div>
                  </div>
                  {/* Content */}
                  <div className="text-slate-600">
                    <div className="grid grid-rows-2">
                      <div>
                        <p className="break-all">Old Value: {ar.oldValue}</p>
                      </div>
                      <div>
                        <p className="break-all">New Value: {ar.newValue}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
