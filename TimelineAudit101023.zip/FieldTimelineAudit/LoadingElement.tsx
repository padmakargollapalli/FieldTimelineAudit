import * as React from "react";

export default function LoadingMessage() {
  return <div>Loading..Please wait</div>;
}
