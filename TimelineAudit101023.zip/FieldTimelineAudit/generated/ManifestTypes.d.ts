/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    textField: ComponentFramework.PropertyTypes.StringProperty;
    targetFieldSchemaName: ComponentFramework.PropertyTypes.StringProperty;
    ctrlLabel: ComponentFramework.PropertyTypes.StringProperty;
    fieldType: ComponentFramework.PropertyTypes.EnumProperty<"1" | "2" | "3" | "4">;
}
export interface IOutputs {
    textField?: string;
}
