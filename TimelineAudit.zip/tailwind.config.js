/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./FieldTimelineAudit/**/*.{html,js,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        inter: ["Inter", "sans-serif"],
        caveat: ["Caveat", "cursive"],
      },
    },
  },
  plugins: [],
};
