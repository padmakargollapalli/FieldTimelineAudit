const headerObj = {
  "OData-MaxVersion": "4.0",
  "OData-Version": "4.0",
  "Content-Type": "application/json; charset=utf-8",
  Accept: "application/json",
  Prefer: "odata.include-annotations=*",
};

export const getAuditData = async (
  fetchUrl: string,
  isHistory?: boolean
): Promise<{}> => {
  const response = await fetch(fetchUrl, {
    method: "GET",
    headers: headerObj,
  });
  const responseJson = await response.json();
  return responseJson;
};
