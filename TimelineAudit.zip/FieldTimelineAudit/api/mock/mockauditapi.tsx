import { mockAuditDetailData } from "../../mockdata/mockAuditDetail";
import { mockAuditHistoryData } from "../../mockdata/mockAuditHistory";

export const getAuditData = async (
  fetchUrl: string,
  isHistory?: boolean
): Promise<{}> => {
  var response = isHistory ? mockAuditHistoryData : mockAuditDetailData;
  return response;
};
