import * as React from "react";
//import { getAuditData } from "../api/auditapi";
import { getAuditData } from "../api/mock/mockauditapi";
import {
  IAuditCollection,
  IAuditDetail,
  IAuditFormattedValue,
  IFormattedValueDetails,
} from "../Interfaces";

const formattedValueColl: IAuditFormattedValue[] = [];
var auditColl: IAuditDetail[] = [];

/**
 * Gets Audit Detail
 * @param props
 */
export default function fetchAuditDetail(
  props: any,
  isFormattedFieldType: boolean
) {
  if (isFormattedFieldType) {
    fetchChangeHistory(props);
  }

 getAuditData(props.fetchUrl, false).then(
    (result: any) => {
      console.log(result);
      if (result.value.length > 0) {
        const auditcollection: IAuditCollection = { auditRecords: [] };

        result.value.map((resultObj: any) => {
          if (resultObj.changedata.indexOf(props.attrName) > 0) {
            var dateField = new Date(resultObj.createdon);
            var dateStr =
              dateField.toLocaleDateString() +
              " " +
              dateField.toLocaleTimeString();
            var changeHistory = JSON.parse(resultObj.changedata);

            changeHistory.changedAttributes.map((attrObj: any) => {
              if (attrObj.logicalName == props.attrName) {
                let oldVal = attrObj.oldValue;
                let newVal = attrObj.newValue;
                let attrName = props.attrName;

                if (props.fieldType == "1") {
                  //lookup
                  let oldLookupArray = oldVal.split(",");
                  let newLookupArray = newVal.split(",");
                  oldVal = oldLookupArray[1];
                  newVal = newLookupArray[1];
                  attrName = "_" + props.attrName + "_value";
                } else if (props.fieldType == "3") {
                  //datetime
                  oldVal = formatDate(oldVal);
                  newVal = formatDate(newVal);
                }

                let auditRec: IAuditDetail = {
                  dateaudited: dateStr,
                  user: resultObj[
                    "_userid_value@OData.Community.Display.V1.FormattedValue"
                  ],
                  oldValue: isFormattedFieldType
                    ? findAuditObj(attrName, oldVal, true)
                    : oldVal,
                  newValue: isFormattedFieldType
                    ? findAuditObj(attrName, newVal, false)
                    : newVal,
                };
                auditcollection.auditRecords.push(auditRec);
              }
            });
          }
        });

        auditColl = auditcollection.auditRecords;
        return auditColl;
      }
    },
    // Note: it's important to handle errors here
    // instead of a catch() block so that we don't swallow
    // exceptions from actual bugs in components.
    (error) => {
      console.error("Error in fetch audit detail", error);
      //  setMessage(
      //    "Error Occured while retrieving audit history. Please check configuration."
      //  );
    }
  );

  return auditColl;
}

function fetchChangeHistory(props: any) {
  getAuditData(props.fetchHistoryUrl, true).then(
    (result: any) => {
      console.log(result);

      var auditDetails = result.AuditDetailCollection.AuditDetails;
      var formattedAttrName =
        props.fieldType == 1 ? "_" + props.attrName + "_value" : props.attrName;

      auditDetails.map((elem: any) => {
        if (elem.OldValue != undefined && elem.NewValue != undefined) {
          var oldValueFormattedObj: IFormattedValueDetails = {
            attrName: formattedAttrName,
            attrValue: elem.OldValue[formattedAttrName],
            formattedValue:
              elem.OldValue[
                formattedAttrName + "@OData.Community.Display.V1.FormattedValue"
              ],
          };
          var newValueFormattedObj: IFormattedValueDetails = {
            attrName: formattedAttrName,
            attrValue: elem.NewValue[formattedAttrName],
            formattedValue:
              elem.NewValue[
                formattedAttrName + "@OData.Community.Display.V1.FormattedValue"
              ],
          };
          formattedValueColl.push({
            oldValue: oldValueFormattedObj,
            newValue: newValueFormattedObj,
          });
        }
      });
    },

    // Note: it's important to handle errors here
    // instead of a catch() block so that we don't swallow
    // exceptions from actual bugs in components.
    (error) => {
      console.error("Error in fetch change history", error);
      // setMessage(
      //    "Error Occured while retrieving audit history. Please check configuration."
      //  );
    }
  );
}

/**
 * Gets Object from Formatted Value Collection
 * @param fieldName
 * @param fieldValue
 * @param fetchOldValue
 * @returns object that matches value
 */

function findAuditObj(
  fieldName: string,
  fieldValue: string,
  fetchOldValue: boolean
) {
  let fValue: any = {};
  let actualValue: any = {};
  if (fetchOldValue) {
    fValue = formattedValueColl.find(
      (elem: any) => elem.oldValue.attrValue == fieldValue
    );
    actualValue = fValue != undefined ? fValue.oldValue : "";
  } else {
    fValue = formattedValueColl.find(
      (elem: any) => elem.newValue.attrValue == fieldValue
    );
    actualValue = fValue != undefined ? fValue.newValue : "";
  }
  return actualValue != null && actualValue.formattedValue != undefined
    ? actualValue.formattedValue
    : actualValue != null
    ? actualValue[fieldName]
    : "";
}
/**
 * Formats date to find in collection
 * @param date
 * @returns formatted date
 */
function formatDate(date: string) {
  if (date == null || date == "") return "";

  var dateParts = date.split(" ");
  var d = new Date(date),
    month = "" + (d.getMonth() + 1),
    day = "" + d.getDate(),
    year = d.getFullYear();

  if (month.length < 2) month = "0" + month;
  if (day.length < 2) day = "0" + day;

  return [year, month, day].join("-") + "T" + dateParts[1] + "Z";
}
