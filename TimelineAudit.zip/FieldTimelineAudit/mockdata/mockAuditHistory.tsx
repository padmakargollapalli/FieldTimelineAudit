export const mockAuditHistoryData = {
  "@odata.context":
    "",
  AuditDetailCollection: {
    MoreRecords: false,
    PagingCookie: "",
    TotalRecordCount: 4,
    AuditDetails: [
      {
        "@odata.type": "#Microsoft.Dynamics.CRM.AttributeAuditDetail",
        InvalidNewValueAttributes: [],
        LocLabelLanguageCode: 0,
        DeletedAttributes: {
          Count: 0,
          Keys: [],
          Values: [],
        },
        OldValue: {
          "@odata.type": "#Microsoft.Dynamics.CRM.contact",
          _parentcustomerid_value: "19614a5f-18f3-ea11-a815-000d3a794b79",
          "_parentcustomerid_value@OData.Community.Display.V1.FormattedValue":"Test 2"
        },
        NewValue: {
          "@odata.type": "#Microsoft.Dynamics.CRM.contact",
          _parentcustomerid_value: "13614a5f-18f3-ea11-a815-000d3a794b79",
          "_parentcustomerid_value@OData.Community.Display.V1.FormattedValue":"Test 3"
        },
      },
      {
        "@odata.type": "#Microsoft.Dynamics.CRM.AttributeAuditDetail",
        InvalidNewValueAttributes: [],
        LocLabelLanguageCode: 0,
        DeletedAttributes: {
          Count: 0,
          Keys: [],
          Values: [],
        },
        OldValue: {
          "@odata.type": "#Microsoft.Dynamics.CRM.contact",
          _parentcustomerid_value: "15614a5f-18f3-ea11-a815-000d3a794b79",
          "_parentcustomerid_value@OData.Community.Display.V1.FormattedValue":"Test 1"
        },
        NewValue: {
          "@odata.type": "#Microsoft.Dynamics.CRM.contact",
          _parentcustomerid_value: "19614a5f-18f3-ea11-a815-000d3a794b79",
          "_parentcustomerid_value@OData.Community.Display.V1.FormattedValue":"Test 2"
        },
      },
      {
        AuditRecord: {
          "@odata.type": "#Microsoft.Dynamics.CRM.audit",
          _objectid_value: "00000000-0000-0000-0000-000000000000",
          _userid_value: "786aa897-afed-ea11-a815-000d3a79607c",
          versionnumber: 0,
          operation: 2,
          createdon: "2023-10-11T01:12:20Z",
          auditid: "843a3d39-d367-ee11-9935-000d3a7993b6",
          action: 105,
          objecttypecode: "contact",
          transactionid: "00000000-0000-0000-0000-000000000000",
        },
      },
      {
        AuditRecord: {
          "@odata.type": "#Microsoft.Dynamics.CRM.audit",
          _objectid_value: "00000000-0000-0000-0000-000000000000",
          _userid_value: "786aa897-afed-ea11-a815-000d3a79607c",
          versionnumber: 0,
          operation: 2,
          createdon: "2023-10-11T01:12:12Z",
          auditid: "5157ea32-d367-ee11-9935-000d3a7993b6",
          attributemask: "",
          action: 107,
          objecttypecode: "organization",
          transactionid: "00000000-0000-0000-0000-000000000000",
        },
      },
    ],
  },
};
