export interface IAuditDetail {
  dateaudited: string;
  user: string;
  oldValue: string;
  newValue: string;
}

export interface IAuditCollection {
  auditRecords: IAuditDetail[];
}

export interface IAuditFormattedValue {
  newValue: IFormattedValueDetails;
  oldValue: IFormattedValueDetails;
}

export interface IFormattedValueDetails {
  attrName: string;
  attrValue: string;
  formattedValue: string;
}
